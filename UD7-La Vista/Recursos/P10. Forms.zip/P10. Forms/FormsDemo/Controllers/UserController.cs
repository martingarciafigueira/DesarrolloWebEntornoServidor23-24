﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FormsDemo.Models;
using FormsDemo.ViewModels;

namespace FormsDemo.Controllers
{
    public class UserController : Controller
    {
        private readonly UserRepository _userRepository;
        public UserController()
        {
            _userRepository = new UserRepository();
        }

        //
        // GET: /Friends/

        public ActionResult Edit()
        {
            var viewModel = new UserViewModel();
            viewModel.UserTypes = UserType.GetUserTypes();
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult Edit(UserViewModel user)
        {
            if(!ModelState.IsValid)
            {
                user.UserTypes = UserType.GetUserTypes();
                return View(user);
            }
            return Content("OK");
        }

        public ActionResult NickExists(string nickName)
        {
            return Json(!_userRepository.Exists(nickName), JsonRequestBehavior.AllowGet);
        }
    }
}
