﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using TemplatedHelpersDemo.Models;
using TemplatedHelpersDemo.ViewModels;

namespace TemplatedHelpersDemo.Controllers
{
    public class UserController : Controller
    {
        private readonly UserRepository _userRepository;
        public UserController()
        {
            _userRepository = new UserRepository();
            Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en");
        }

        //
        // GET: /Friends/

        public ActionResult Edit(bool auto = false)
        {
            var viewModel = new UserViewModel();
            viewModel.Birthdate = DateTime.Now;
            ViewBag.UserTypes = UserType.GetUserTypes();
            return View(auto? "AutomaticEditor": "CustomEditor", viewModel);
        }

        [HttpPost]
        public ActionResult Edit(UserViewModel user, bool auto = false)
        {
            if(!ModelState.IsValid)
            {
                ViewBag.UserTypes = UserType.GetUserTypes();
                return View(auto ? "AutomaticEditor" : "CustomEditor", user);
            }
            return Content("OK");
        }

        public ActionResult NickExists(string nickName)
        {
            return Json(!_userRepository.Exists(nickName), JsonRequestBehavior.AllowGet);
        }
    }
}
