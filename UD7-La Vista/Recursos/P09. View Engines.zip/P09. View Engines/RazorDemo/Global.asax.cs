﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace RazorDemo
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            // Reorder view engines. First, Razor.
            var webformViewEngine = ViewEngines.Engines[0];
            ViewEngines.Engines.RemoveAt(0);
            ViewEngines.Engines.Add(webformViewEngine);

            // Add a new location format
            var razorViewEngine = ViewEngines.Engines[0] as RazorViewEngine;
            var extendedLocationFormats = new List<string>();
            extendedLocationFormats.Add("~/Views/{1}/Extra/{0}.cshtml");
            extendedLocationFormats.AddRange(razorViewEngine.ViewLocationFormats);
            razorViewEngine.ViewLocationFormats = extendedLocationFormats.ToArray();

            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
        }
    }
}
