﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ValidationDemo.Models;

namespace ValidationDemo.Controllers
{
    public class FriendsController : Controller
    {
        public ActionResult Edit()
        {
            return View();
        }

        public ActionResult Save(Friend friend)
        {
            return Content("Entity is valid: " + ModelState.IsValid);
        }
    }
}
