﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ValidationDemo.Models;

namespace ValidationDemo.Controllers
{
    public class TestController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Edit()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Edit(TestEntity entity)
        {
            if (!ModelState.IsValid)
                return View();

            return Content("Valid!");
        }

    }

}
