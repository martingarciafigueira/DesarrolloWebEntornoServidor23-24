﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ValidationDemo.Models
{
    public class TestEntity
    {
        [Required]
        [Display(Name="Required string")]
        public string Required { get; set; }

        [StringLength(50, MinimumLength = 5)]
        [Display(Name="String (min 5 chars, max 50 chars)")]
        public string StringMax50Min5 { get; set; }

        [Range(1, 10)]
        [Display(Name="Integer between 1 and 10")]
        public int IntBetween1And10 { get; set; }

        [RegularExpression("hello")]
        [Display(Name="String containing hello")]
        public string RegExContainsSubstringHello { get; set; }


        [Display(Name="Any string")]
        public string Compare1 { get; set; }
        [Compare("Compare1")]
        [Display(Name="Any string (must match the previous one)")]
        public string Compare2 { get; set; }



    }
}