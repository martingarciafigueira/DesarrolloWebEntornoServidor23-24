﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ValidationDemo.Models
{
    public class Friend: IValidatableObject
    {
        [Required, StringLength(40)]
        public string Name { get; set; }

        [Range(1, 120)]
        public int Age { get; set; }

        public string Email { get; set; }
        public string PhoneNumber { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (string.IsNullOrWhiteSpace(this.Email)
                && string.IsNullOrWhiteSpace(this.PhoneNumber))
                yield return new ValidationResult("Email or Phone number are required");

            yield return ValidationResult.Success;
        }
    }

}